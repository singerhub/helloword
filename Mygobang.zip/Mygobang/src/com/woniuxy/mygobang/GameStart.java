package com.woniuxy.mygobang;
import java.text.MessageFormat;

/*
 * 
 * 
 * */
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Border;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.stage.Stage;
@SuppressWarnings("unused")
public class GameStart extends Application{
	
	private int width=650;
	private int height=650;
	int lines=15;
	int margin=40;
	int padding=40;
	boolean isBlack=true;//������ɫ
	private Chess[] chesses=new Chess[lines*lines];
	private int count;//���Ӹ���
	private int Wincount=1;
	private boolean isWin=false;
	public void start(Stage primaryStage) throws Exception {
		//�������
		Pane pane = getPane();
	
		//���ñ�����ɫ
		pane.setBackground(new Background(new BackgroundFill(Color.GREENYELLOW, null, null)));
		//��������
		Scene scene = Scene(pane, 600, 600);
		
		primaryStage.setScene(scene);
		// չʾ��̨
		primaryStage.show();
		
		//��������
		panintPane(pane);
		//����		
		//������¼���ʵ�����ӹ���
		pane.setOnMouseClicked(new EventHandler<MouseEvent>() {
			private Object chessFind;
			@Override
			public void handle(MouseEvent event) {
				//����¼��Ĳ������Ի�ȡ�����������λ��
				double x=event.getX();
				double y=event.getY();
				
				//�ж����ӱ߽�
				//System.out.println("x="+x+",y="+y);
				if(!(x>margin&&x<margin+padding*14&&y>margin&&y<margin+padding*14))
					System.out.println("����");
				System.out.println(MessageFormat.format("x={0},y={1}", x,y));
				//Circle circle=new Circle(x, y, 10);
				//pane.getChildren().add(circle);
				/*
				 * 
				 */
				
				int xNum=((int)x-margin+padding/2)/padding;
				int yNum=((int)y-margin+padding/2)/padding;
				System.out.println(MessageFormat
						.format("x={0},y={1},xNum={2},yNum={3}", x, y,xNum,yNum));
				//Circle circle=new Circle(xNum*padding+margin, yNum*padding+margin, 15,Color.WHEAT);
				//pane.getChildren().add(circle);
				//�ظ�����
				if(haseChess(xNum,yNum)){
					return;
				}
				
				//���Ӻڰ׽���
				Circle circle=null;
				Chess chess=null;
				if(isBlack) {
					circle=new Circle(xNum*padding+margin, yNum*padding+margin, 15,Color.BLACK);
					chess=new Chess(xNum, yNum, Color.BLACK);
				}else {
					circle=new Circle(xNum*padding+margin, yNum*padding+margin, 15,Color.WHITE);
					chess=new Chess(xNum, yNum, Color.WHITE);
				}
				isBlack=!isBlack;
				pane.getChildren().add(circle);
				chesses[count]=chess;
				count++;
			}
			
			private boolean isWin(Chess chess) {
				//���� 
				Wincount=1;
				int xNum=chess.getX();
				int yNum=chess.getY();
				///�ұ�
				for(int t=xNum+1;t<xNum+4&&t<lines;t++) {
					Chess chessfind=getChess(t, yNum);
					if(chessfind!=null&&chessfind.getColor().equals(chess.getColor())) {
						Wincount++;
					}else {
						break;
					}
				}
				
				//z
				for(int i=xNum-1;i>=0;i--) {
					Chess chessfind=getChess(i, yNum);
					if(chessfind!=null&&chessfind.getColor().equals(chess.getColor())) {
						Wincount++;
					}else {
						break;
					}
				}
				if(Wincount>=5)	{
					System.out.println("Win");
				}
				return false;
				
				//��������
			}
			private Chess getChess(int xNum,int yNum) {
				for (int i = 0; i < count; i++) {
					Chess chess = chesses[i];
					if(chess.getX()==xNum&&chess.getY()==yNum) {
						return chess;
					}
				}
				return null;
			}
			
		
		});
			//

	}
	private boolean haseChess(int xNum, int yNum) {
		for(int i=0;i<count;i++) {
			Chess chess=chesses[i];
			if(chess.getX()==xNum&&chess.getY()==yNum) {
				return true;
			}
		}
		return false;
	}
	public void panintPane(Pane pane) {
		//
		for(int i=0;i<lines;i++) {
		Line row=new Line(margin, margin+padding*i, margin+(lines-1)*padding, margin+padding*i);
		Line tr=new Line(margin+padding*i, margin, margin+padding*i, margin+(lines-1)*padding);
		//�����������ӵ�pane��ʾ
		pane.getChildren().add(row);
		pane.getChildren().add(tr);
		}
	}
	public Scene Scene(Pane pane,int width,int height) {
		Scene scene=new Scene(pane, width, height);
		return scene;
	}
	private Pane getPane() {
		Pane pane=new Pane();
		return pane;
	}
	public static void main(String[] args) {
		//����windows���򣬵ײ�����start()����
		launch(args);
	}

}

